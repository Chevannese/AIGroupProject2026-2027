"""
Project: Path-Finder for Rural Roads Network in Python/Prolog
Module Name: Artificial Intelligence
Module Code: CIT3003

Group Members:
Chevannese Ellis (2301109),
Jonathan Blackwood (2306822),
Daniel Lowe (2300734),
Jermaine Lewis (2307120),
Tianna Dillion (2205580)

Due Date: Nov 25, 2026


"""
from pyswip import *
from pyswip import Prolog




from tkinter import *
from tkinter.messagebox import showinfo, showerror
from tkinter.ttk import *
from pathlib import Path
import os
import re
import json
from datetime import datetime


PENALTY_CONDITIONS = {"broken_cisterns", "deep_potholes"}
PENALTY_MINUTES = 5

COLUMNS = ("Source", "Destination", "Distance", "Time", "Type", "Special", "Status", "Direction")

# Dropdown values for the editable table (stored in Prolog format)
DROPDOWNS = {
    "Type": ["paved", "unpaved"],
    "Special": ["none", "broken_cisterns", "severely_damaged_road",
                "blocked_road", "deep_potholes", "falling_rocks",
                "seasonally_blocked"],
    "Status": ["open", "closed"],
    "Direction": ["two_way", "one_way"],
}



FACT_PATTERN = re.compile(
    r"location\(source\((.*?)\),destination\((.*?)\),distance\((.*?)\),"
    r"time\((.*?)\),type\((.*?)\),special\((.*?)\),status\((.*?)\)"
    r"(?:,bidirectional\((.*?)\))?\)\."
)

tree = None  # set when the Update Network tab is built

def fmt_time(t):
    return int(t) if float(t) == int(t) else float(t)

def load_road_data():
    rows = []
    if file_path.exists():
        with open(file_path) as f:
            for line in f:
                m = FACT_PATTERN.match(line.strip())
                if m:
                    # facts saved without a bidirectional part are two-way roads
                    row = list(m.groups())
                    row[7] = "one_way" if row[7] == "no" else "two_way"
                    rows.append(tuple(row))
    return rows


def row_to_fact(v):
    clean = lambda x: str(x).strip().lower().replace(" ", "_")
    return (
        f"location(source({clean(v[0])}),destination({clean(v[1])}),"
        f"distance({str(v[2]).strip()}),time({str(v[3]).strip()}),"
        f"type({clean(v[4])}),special({clean(v[5])}),status({clean(v[6])}),"
        f"bidirectional({'no' if str(v[7]) == 'one_way' else 'yes'}))."
    )


def refresh_table():
    if tree is None:
        return
    tree.delete(*tree.get_children())
    for row in load_road_data():
        tree.insert("", END, values=row)


def save_table():
    # Validate numbers first
    for iid in tree.get_children():
        v = tree.item(iid)["values"]
        try:
            float(v[2])
            float(v[3])
        except ValueError:
            showerror("Invalid data", f"Distance and Time must be numbers (row: {v[0]} -> {v[1]}).")
            return
    with open(file_path, "w") as f:
        for iid in tree.get_children():
            f.write(row_to_fact(tree.item(iid)["values"]) + "\n")
    # send the saved roads to Prolog so route finding uses them
    load_into_prolog()
    refresh_places()
    refresh_incident_roads()
    showinfo("Success", "Road network updated.")


def delete_selected():
    for iid in tree.selection():
        tree.delete(iid)


active_editor = None


def apply_special_change(iid, old_special, new_special):
    """Add/remove the 5-minute penalty when the Special condition changes."""
    # roads that are blocked or badly damaged are closed automatically
    if new_special in FORCE_CLOSED:
        tree.set(iid, "Status", "closed")
    try:
        t = float(tree.set(iid, "Time"))
    except ValueError:
        return
    if new_special in PENALTY_CONDITIONS and old_special not in PENALTY_CONDITIONS:
        t += PENALTY_MINUTES
    elif old_special in PENALTY_CONDITIONS and new_special not in PENALTY_CONDITIONS:
        t -= PENALTY_MINUTES
    tree.set(iid, "Time", fmt_time(max(t, 0)))


def close_editor(event=None):
    global active_editor
    if active_editor is not None and active_editor.winfo_exists():
        active_editor.destroy()
    active_editor = None


def on_double_click(event):
    global active_editor
    if tree.identify_region(event.x, event.y) != "cell":
        return
    close_editor()

    iid = tree.identify_row(event.y)
    col = tree.identify_column(event.x)
    name = COLUMNS[int(col[1:]) - 1]
    x, y, w, h = tree.bbox(iid, col)
    old = str(tree.set(iid, name)).strip()

    is_dropdown = name in DROPDOWNS
    if is_dropdown:
        editor = Combobox(tree, values=DROPDOWNS[name], state="readonly")
        editor.set(old)
    else:
        editor = Entry(tree)
        editor.insert(0, old)
        editor.select_range(0, END)

    active_editor = editor
    editor.place(x=x, y=y, width=w, height=h)
    editor.focus_set()

    def commit(e=None):
        if not editor.winfo_exists():
            return
        new = editor.get().strip()
        if name == "Special" and new != old:
            apply_special_change(iid, old, new)
        tree.set(iid, name, new)
        close_editor()

    editor.bind("<Return>", commit)
    editor.bind("<Escape>", close_editor)
    if is_dropdown:
        editor.bind("<<ComboboxSelected>>", commit)   # commit only on a real selection
    else:
        editor.bind("<FocusOut>", commit)             # text cells still commit on click-away

    def cancel(e=None):
        if editor.winfo_exists():
            editor.destroy()

    editor.bind("<Return>", commit)
    editor.bind("<FocusOut>", commit)
    editor.bind("<Escape>", cancel)
    if name in DROPDOWNS:
        editor.bind("<<ComboboxSelected>>", commit)


# Conditions that make a road unusable, so the road is closed automatically
FORCE_CLOSED = {"severely_damaged_road", "blocked_road", "seasonally_blocked"}

# Route criterion shown to the user -> criterion name used by find_route/6 in road_network.pl
CRITERIA = {
    "Shortest distance": "shortest_distance",
    "Fastest route": "fastest_route",
    "Avoid closed roads": "avoid_closed",
    "Avoid unpaved roads": "avoid_unpaved",
    "Avoid roads with broken cisterns": "avoid_broken_cisterns",
    "Avoid roads with deep potholes": "avoid_deep_potholes",
    "Fewest stops (BFS, ignores closures)": "loose_constraints",
}

# Algorithm that road_network.pl runs for each criterion (shown in the result)
ALGORITHMS = {
    "shortest_distance": "Dijkstra's algorithm",
    "fastest_route": "Dijkstra's algorithm",
    "avoid_closed": "Dijkstra's algorithm",
    "avoid_unpaved": "A* search",
    "avoid_broken_cisterns": "A* search",
    "avoid_deep_potholes": "A* search",
    "loose_constraints": "Breadth-first search",
}

# Incident types for the AI tab: label shown -> rule name used by assess_incident()
INCIDENT_TYPES = {
    "Pothole (enter depth in inches)": "pothole",
    "Falling rocks (enter risk level)": "falling_rocks",
    "Broken cistern": "broken_cistern",
    "Severely damaged road": "severe_damage",
    "Road blocked": "blocked",
    "Seasonal blockage": "seasonal_block",
    "Problem cleared / repaired": "cleared",
}

# Severity ranking so a minor report never replaces a worse condition
SEVERITY = {"none": 0, "broken_cisterns": 1, "deep_potholes": 1, "falling_rocks": 2,
            "severely_damaged_road": 3, "blocked_road": 3, "seasonally_blocked": 3}

# History of route requests and incident reports is kept here, not in road_network.pl
history_path = Path("road_history.json")

route_widgets = {}
incident_widgets = {}
history_trees = {}


# Turns user text such as "St Ann" into a valid Prolog atom (st_ann); returns "" if it cannot
def to_atom(text):
    atom = re.sub(r"\s+", "_", str(text).strip().lower())
    return atom if re.match(r"^[a-z][a-z0-9_]*$", atom) else ""


def pretty(atom):
    return str(atom).replace("_", " ").title()


# pyswip may hand back str, bytes or an Atom object; always return plain text
def text(value):
    if isinstance(value, bytes):
        return value.decode("utf-8")
    if hasattr(value, "value") and not isinstance(value, (int, float, str)):
        return str(value.value)
    return str(value)


# Minutes to add or remove when a road's condition changes (the 5-minute rule)
def penalty_change(old, new):
    if new in PENALTY_CONDITIONS and old not in PENALTY_CONDITIONS:
        return PENALTY_MINUTES
    if old in PENALTY_CONDITIONS and new not in PENALTY_CONDITIONS:
        return -PENALTY_MINUTES
    return 0


# Save a list of rows to road_data.pl
def write_rows(rows):
    with open(file_path, "w") as f:
        for row in rows:
            f.write(row_to_fact(row) + "\n")


# True if a road between the two places exists already (same direction, or a two-way road the other way)
def road_exists(source, destination, bidirectional):
    for r in load_road_data():
        a, b, two_way = to_atom(r[0]), to_atom(r[1]), r[7] == "two_way"
        if (a, b) == (source, destination):
            return True
        if (b, a) == (source, destination) and (two_way or bidirectional == "yes"):
            return True
    return False


# Replace the roads held in Prolog with the roads saved in road_data.pl
def load_into_prolog():
    list(prolog.query("delallroad"))
    for r in load_road_data():
        atoms = [to_atom(r[0]), to_atom(r[1]), to_atom(r[4]), to_atom(r[5]), to_atom(r[6])]
        if not all(atoms):
            continue
        direction = "no" if r[7] == "one_way" else "yes"
        list(prolog.query(
            f"addroad({atoms[0]},{atoms[1]},{r[2]},{r[3]},{atoms[2]},{atoms[3]},{atoms[4]},{direction})"))


# Append one history record (kind is "routes" or "incidents") to road_history.json
def log_event(kind, record):
    record = dict(record, kind=kind, when=datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
    with open(history_path, "a") as f:
        f.write(json.dumps(record) + "\n")


def read_events(kind):
    events = []
    if history_path.exists():
        with open(history_path) as f:
            for line in f:
                try:
                    record = json.loads(line)
                except ValueError:
                    continue
                if record.get("kind") == kind:
                    events.append(record)
    return events


# Warnings for the roads on a route: closed, unpaved or with a special condition
def route_notes(path, rows):
    notes = []
    for a, b in zip(path, path[1:]):
        for r in rows:
            forward = (to_atom(r[0]), to_atom(r[1])) == (a, b)
            backward = (to_atom(r[0]), to_atom(r[1])) == (b, a) and r[7] == "two_way"
            if forward or backward:
                if r[6] == "closed":
                    notes.append(f"WARNING: the road {pretty(a)} to {pretty(b)} is CLOSED.")
                if r[4] == "unpaved":
                    notes.append(f"Note: the road {pretty(a)} to {pretty(b)} is unpaved.")
                if r[5] != "none":
                    notes.append(f"Note: the road {pretty(a)} to {pretty(b)} has {r[5].replace('_', ' ')}.")
                break
    return notes


# Asks Prolog (find_route/6 in road_network.pl) for a route.
# Returns (status, path, distance, time, notes)
def run_route(criterion, source, destination):
    rows = load_road_data()
    places = {to_atom(r[0]) for r in rows} | {to_atom(r[1]) for r in rows}
    if source not in places or destination not in places:
        return "unknown_place", [], 0, 0, []
    if source == destination:
        return "same_place", [source], 0, 0, []
    found = list(prolog.query(
        f"find_route({criterion},{source},{destination},P,D,T)", maxresult=1))
    if found:
        path = [text(p) for p in found[0]["P"]]
        return ("found", path, fmt_time(round(float(found[0]["D"]), 2)),
                fmt_time(round(float(found[0]["T"]), 2)), route_notes(path, rows))
    loose = list(prolog.query(
        f"find_route(loose_constraints,{source},{destination},P,D,T)", maxresult=1))
    if loose:
        return "no_path", [], 0, 0, ["A route exists, but only through roads your criteria exclude."]
    return "no_path", [], 0, 0, ["No road connects these places in this direction (check one-way roads)."]


# Find Route tab: choose two places and one criterion, then show the route Prolog finds
def build_route_tab(frame):
    left = Frame(frame)
    left.pack(side="left", fill="y", padx=15, pady=15)
    right = Frame(frame)
    right.pack(side="left", fill="both", expand=True, padx=15, pady=15)

    Label(left, text="Starting point").pack(anchor="w")
    route_widgets["start"] = Combobox(left, state="readonly", width=28)
    route_widgets["start"].pack(pady=(0, 8))
    Label(left, text="Destination").pack(anchor="w")
    route_widgets["goal"] = Combobox(left, state="readonly", width=28)
    route_widgets["goal"].pack(pady=(0, 12))

    Label(left, text="Route criteria:", font=("Arial", 10, "bold")).pack(anchor="w")
    route_widgets["criterion"] = StringVar(value="Shortest distance")
    for label in CRITERIA:
        Radiobutton(left, text=label, value=label,
                    variable=route_widgets["criterion"]).pack(anchor="w")
    Button(left, text="Find Route", command=find_route_action).pack(fill="x", pady=(14, 4))
    Button(left, text="Swap start / destination", command=swap_places).pack(fill="x")

    route_widgets["banner"] = Label(right, text="Choose a start and destination, then press Find Route.",
                                    font=("Arial", 12, "bold"))
    route_widgets["banner"].pack(anchor="w")
    route_widgets["result"] = Text(right, height=14, wrap="word", state="disabled")
    route_widgets["result"].pack(fill="both", expand=True, pady=8)


def swap_places():
    start, goal = route_widgets["start"].get(), route_widgets["goal"].get()
    route_widgets["start"].set(goal)
    route_widgets["goal"].set(start)


# Refresh the place lists in Find Route after the network changes
def refresh_places():
    if "start" not in route_widgets:
        return
    rows = load_road_data()
    places = sorted({to_atom(r[0]) for r in rows} | {to_atom(r[1]) for r in rows})
    names = [pretty(p) for p in places]
    for key in ("start", "goal"):
        route_widgets[key]["values"] = names
        if route_widgets[key].get() not in names:
            route_widgets[key].set("")


def show_result(box, content):
    box.config(state="normal")
    box.delete("1.0", END)
    box.insert(END, content)
    box.config(state="disabled")


# Runs the route search, shows places / distance / time or the no-path notice, and stores the request
def find_route_action():
    source = to_atom(route_widgets["start"].get())
    destination = to_atom(route_widgets["goal"].get())
    if not source or not destination:
        showerror("Missing input", "Please choose both a starting point and a destination.")
        return
    criterion = CRITERIA[route_widgets["criterion"].get()]
    status, path, distance, minutes, notes = run_route(criterion, source, destination)

    if status == "found":
        route_widgets["banner"].config(text="Route found")
        content = ("Places on the route:\n" + "  ->  ".join(pretty(p) for p in path) + "\n\n"
                   f"Total distance: {distance} km\n"
                   f"Total travel time: {minutes} minutes\n"
                   f"Algorithm used: {ALGORITHMS[criterion]}\n")
        if notes:
            content += "\n" + "\n".join(notes) + "\n"
        show_result(route_widgets["result"], content)
    elif status == "no_path":
        route_widgets["banner"].config(text="No path available")
        show_result(route_widgets["result"],
                    f"There is no route from {pretty(source)} to {pretty(destination)} "
                    "with the chosen criteria.\n\n" + "\n".join(notes))
        showinfo("No path available",
                 f"No route is available from {pretty(source)} to {pretty(destination)} "
                 "with the chosen criteria.")
    elif status == "same_place":
        route_widgets["banner"].config(text="You are already there")
        show_result(route_widgets["result"], "Start and destination are the same place: 0 km, 0 minutes.")
    else:
        route_widgets["banner"].config(text="Cannot search")
        show_result(route_widgets["result"], "One of the places is not in the road network.")

    log_event("routes", {"criterion": criterion, "start": source, "goal": destination,
                         "status": status, "distance": distance, "time": minutes})
    refresh_history()


# AI rule base: turns a reported incident into (new special condition, new status, explanation).
# None for either value means "leave unchanged". Returns None if the measurement is invalid.
def assess_incident(incident, measure):
    if incident == "pothole":
        try:
            depth = float(measure)
        except ValueError:
            return None
        if depth > 3:
            return ("deep_potholes", None, "Pothole deeper than 3 inches: marked as deep potholes (+5 minutes).")
        return (None, None, "Pothole of 3 inches or less is minor: road left unchanged.")
    if incident == "falling_rocks":
        if measure == "high":
            return ("falling_rocks", "closed", "High risk of falling rocks: road closed for safety.")
        if measure == "medium":
            return ("falling_rocks", None, "Medium risk of falling rocks: road stays open but is flagged.")
        if measure == "low":
            return (None, None, "Low risk of falling rocks: road left unchanged.")
        return None
    if incident == "broken_cistern":
        return ("broken_cisterns", None, "Broken cistern reported: flagged (+5 minutes).")
    if incident == "severe_damage":
        return ("severely_damaged_road", "closed", "Severely damaged road: closed until repaired.")
    if incident == "blocked":
        return ("blocked_road", "closed", "Road blocked: closed until cleared.")
    if incident == "seasonal_block":
        return ("seasonally_blocked", "closed", "Seasonal blockage: road closed for the season.")
    if incident == "cleared":
        return ("none", "open", "Problem cleared: road restored to normal and reopened.")
    return None


# Report Incident (AI) tab: the system decides the road's new condition and status from the report
def build_incident_tab(frame):
    Label(frame, text="Report an Incident - AI Assessment", font=("Arial", 16, "bold")).pack(pady=15)
    form = Frame(frame)
    form.pack()
    Label(form, text="Road:").grid(row=0, column=0, sticky="w", padx=8, pady=8)
    incident_widgets["road"] = Combobox(form, state="readonly", width=34)
    incident_widgets["road"].grid(row=0, column=1, padx=8, pady=8)
    Label(form, text="What happened:").grid(row=1, column=0, sticky="w", padx=8, pady=8)
    incident_widgets["type"] = Combobox(form, state="readonly", width=34, values=list(INCIDENT_TYPES))
    incident_widgets["type"].grid(row=1, column=1, padx=8, pady=8)
    incident_widgets["type"].current(0)
    incident_widgets["type"].bind("<<ComboboxSelected>>", on_incident_type)
    incident_widgets["measure_label"] = Label(form, text="Depth (inches):")
    incident_widgets["measure_label"].grid(row=2, column=0, sticky="w", padx=8, pady=8)
    incident_widgets["measure"] = Combobox(form, width=34)
    incident_widgets["measure"].grid(row=2, column=1, padx=8, pady=8)
    Button(frame, text="Assess and Update Road", command=report_incident_action).pack(pady=10)
    incident_widgets["result"] = Text(frame, height=6, width=90, wrap="word", state="disabled")
    incident_widgets["result"].pack(pady=10)
    on_incident_type()


# Show the right measurement input for the chosen incident type
def on_incident_type(event=None):
    incident = INCIDENT_TYPES[incident_widgets["type"].get()]
    box = incident_widgets["measure"]
    if incident == "pothole":
        incident_widgets["measure_label"].config(text="Depth (inches):")
        box.config(state="normal", values=["1", "2", "3", "4", "5", "6", "8", "10"])
        box.set("4")
    elif incident == "falling_rocks":
        incident_widgets["measure_label"].config(text="Risk level:")
        box.config(state="readonly", values=["low", "medium", "high"])
        box.set("high")
    else:
        incident_widgets["measure_label"].config(text="Measurement:")
        box.config(state="normal", values=[])
        box.set("not needed")
        box.config(state="disabled")


def refresh_incident_roads():
    if "road" not in incident_widgets:
        return
    labels = [f"{pretty(to_atom(r[0]))} -> {pretty(to_atom(r[1]))}" for r in load_road_data()]
    incident_widgets["road"]["values"] = labels
    if incident_widgets["road"].get() not in labels:
        incident_widgets["road"].set("")


# Applies the AI assessment to the chosen road: updates its condition, status and time
# (including the 5-minute rule), saves it, reloads Prolog and stores the report
def report_incident_action():
    label = incident_widgets["road"].get()
    rows = [list(r) for r in load_road_data()]
    index = None
    for i, r in enumerate(rows):
        if f"{pretty(to_atom(r[0]))} -> {pretty(to_atom(r[1]))}" == label:
            index = i
    if index is None:
        showerror("Missing input", "Please choose a road.")
        return
    incident = INCIDENT_TYPES[incident_widgets["type"].get()]
    measure = incident_widgets["measure"].get().strip().lower() if incident in ("pothole", "falling_rocks") else "yes"
    outcome = assess_incident(incident, measure)
    if outcome is None:
        showerror("Invalid data", "Pothole needs a depth in inches; falling rocks needs low, medium or high.")
        return
    new_special, new_status, why = outcome

    row = rows[index]
    old_special, old_status, old_time = row[5], row[6], float(row[3])
    if incident == "cleared":
        special = "none"
    elif new_special and SEVERITY[new_special] >= SEVERITY.get(old_special, 0):
        special = new_special
    else:
        special = old_special
    status = new_status or old_status
    if special in FORCE_CLOSED:
        status = "closed"
    new_time = fmt_time(max(0, old_time + penalty_change(old_special, special)))
    row[3], row[5], row[6] = str(new_time), special, status

    write_rows(rows)
    load_into_prolog()
    refresh_table()
    refresh_places()
    show_result(incident_widgets["result"],
                f"AI assessment:\n{why}\nCondition: {old_special} -> {special}\n"
                f"Status: {old_status} -> {status}\nTime: {fmt_time(old_time)} -> {new_time} min")
    log_event("incidents", {"road": label, "incident": incident, "measure": measure,
                            "condition": special, "status": status})
    refresh_history()


# History tab: stored route requests and incident reports
def build_history_tab(frame):
    Label(frame, text="Route requests", font=("Arial", 12, "bold")).pack(anchor="w", padx=10, pady=(10, 2))
    routes = ("When", "From", "To", "Criteria", "Outcome", "Km", "Mins")
    history_trees["routes"] = Treeview(frame, columns=routes, show="headings", height=7)
    incidents = ("When", "Road", "Incident", "Measure", "New condition", "New status")
    history_trees["incidents"] = Treeview(frame, columns=incidents, show="headings", height=7)
    for key, columns in (("routes", routes), ("incidents", incidents)):
        for c in columns:
            history_trees[key].heading(c, text=c)
            history_trees[key].column(c, width=110, anchor="center")
        history_trees[key].pack(fill="x", padx=10)
        if key == "routes":
            Label(frame, text="Incident reports", font=("Arial", 12, "bold")).pack(anchor="w", padx=10, pady=(10, 2))


def refresh_history():
    if "routes" not in history_trees:
        return
    for key in ("routes", "incidents"):
        history_trees[key].delete(*history_trees[key].get_children())
    for e in reversed(read_events("routes")):
        history_trees["routes"].insert("", END, values=(
            e["when"], pretty(e["start"]), pretty(e["goal"]), e["criterion"].replace("_", " "),
            e["status"].replace("_", " "), e["distance"], e["time"]))
    for e in reversed(read_events("incidents")):
        history_trees["incidents"].insert("", END, values=(
            e["when"], e["road"], e["incident"].replace("_", " "), e["measure"],
            e["condition"].replace("_", " "), e["status"]))


# run from this file's folder so road_network.pl and road_data.pl are found
os.chdir(Path(__file__).resolve().parent)
print(os.getcwd())
# File path
default_road_network_data = [
    "location(source(a),destination(b),distance(5),time(10),type(paved),special(none),status(open)).",
    "location(source(b),destination(c),distance(3),time(15),type(unpaved),special(broken_cisterns),status(open)).",
    "location(source(c),destination(d),distance(7),time(12),type(paved),special(deep_potholes),status(closed))."
]
# Roads added or edited in the app are saved here; road_network.pl is never written to
file_path = Path("road_data.pl")
rules_path = Path("road_network.pl")

# Check if the file exists
if file_path.exists():
    print("Loaded: Road Network Data")
else:
    with open(file_path, "w") as file:
        for line in default_road_network_data:
            file.write(line + "\n")
    print("Creation: Default Road Network Data")

# Start Prolog, load the unchanged road_network.pl rules, then copy the saved roads into it
prolog = Prolog()
prolog.consult(rules_path.as_posix())
load_into_prolog()

#Login Page
def login_window():
    # Create the main window
    parent = Tk()
    parent.geometry('800x500')
    parent.title("Login Form")

    # Create and place the username label and entry
    username_label = Label(parent, text="Userid:")
    username_label.pack()

    username_entry = Entry(parent)
    username_entry.pack()

    # Create and place the password label and entry
    password_label = Label(parent, text="Password:")
    password_label.pack()

    password_entry = Entry(parent, show="*")  # Show asterisks for password
    password_entry.pack()

    # Create and place the login button
    login_button = Button(parent, text="Login", command=lambda: login(username_entry.get(), password_entry.get(), parent))
    login_button.pack()

    # users find routes without a password
    user_button = Button(parent, text="Continue as User", command=lambda: user_login(parent))
    user_button.pack(pady=10)

    # Start the Tkinter event loop
    parent.mainloop()

def main_window(role="admin"):
    global entries
    entries = {}


    # Root window
    root = Tk()
    root.geometry('950x620')
    root.title('Path Finder Application')

    # Notebook
    notebook = Notebook(root)
    notebook.pack(padx=10, pady=10, fill='both', expand=True)

    # Frames
    frame1 = Frame(notebook)
    frame2 = Frame(notebook)
    frame3 = Frame(notebook)
    frame4 = Frame(notebook)
    frame5 = Frame(notebook)

    notebook.add(frame1, text='Network Input Form')
    notebook.add(frame2, text='Update Network')
    notebook.add(frame3, text='Find Route')
    notebook.add(frame4, text='Report Incident (AI)')
    notebook.add(frame5, text='History')

  
    #NETWORK INPUT FORM


    title_label = Label(
        frame1,
        text="Network Input Form",
        font=("Arial", 16, "bold")
    )
    title_label.pack(pady=20)

    form_frame = Frame(frame1)
    form_frame.pack(pady=10)
    
    # Form fields
    fields = [
        "Source",
        "Destination",
        "Distance (In Kilometers)",
        "Travel Time (Mins)",
        "Road Type",
        "Special Condition",
        "Road Status",
        "Direction"
    ]

    # Dropdown options
    road_type_options = [
        "Paved", "Unpaved"
    ]

    road_status_options = [
        "Open", "Closed"
    ]

    special_condition_options = [
        "None","Broken Cisterns", "Severely Damaged Road", "Blocked Road", "Deep Potholes", "Falling Rocks", "Seasonally Blocked"
    ]

    for i, field in enumerate(fields):

        label = Label(form_frame, text=field + ":")
        label.grid(row=i, column=0, padx=10, pady=10, sticky="w")

        # Create dropdowns for specific fields
        if field == "Road Type":
            entry = Combobox(
                form_frame,
                values=road_type_options,
                width=32,
                state="readonly"
            )

        elif field == "Road Status":
            entry = Combobox(
                form_frame,
                values=road_status_options,
                width=32,
                state="readonly"
            )

        elif field == "Special Condition":
            entry = Combobox(
                form_frame,
                values=special_condition_options,
                width=32,
                state="readonly"
            )
        elif field == "Distance (In Kilometers)":
            entry = Spinbox(
                form_frame,
                from_=0.1,
                to=1000,
                increment=0.1,
                width=33
        )
            
        elif field == "Travel Time (Mins)":
            entry = Spinbox(
                form_frame,
                from_=1,
                to=1440,
                increment=1,
                width=33
            )
        elif field == "Direction":
            entry = Combobox(
                form_frame,
                values=["Two-way", "One-way"],
                width=32,
                state="readonly"
            )
        else:
            entry = Entry(form_frame, width=35)

        entry.grid(row=i, column=1, padx=10, pady=10)

        # dropdowns start on their first value so a field is never left blank
        if isinstance(entry, Combobox):
            entry.current(0)

        entries[field] = entry
        
            
    submit_button = Button(
        form_frame,
        text="Submit",
        command=submit_form
    )
    submit_button.grid(row=len(fields), column=1, pady=20, sticky="e")


    # UPDATE NETWORK TABLE

    update_network_label = Label(
        frame2,
        text="Update Existing Road Networks",
        font=("Arial", 16, "bold")
    )
    update_network_label.pack(pady=10)

    global tree
    table_frame = Frame(frame2)
    table_frame.pack(fill="both", expand=True, padx=10)

    tree = Treeview(table_frame, columns=COLUMNS, show="headings", selectmode="extended")
    for c in COLUMNS:
        tree.heading(c, text=c)
        tree.column(c, width=90, anchor="center")

    scroll = Scrollbar(table_frame, orient="vertical", command=tree.yview)
    tree.configure(yscrollcommand=scroll.set)
    tree.pack(side="left", fill="both", expand=True)
    scroll.pack(side="right", fill="y")

    tree.bind("<Double-1>", on_double_click)
    tree.bind("<Button-1>", close_editor, add="+")

    button_frame = Frame(frame2)
    button_frame.pack(pady=10)
    Button(button_frame, text="Save Changes", command=save_table).pack(side="left", padx=5)
    Button(button_frame, text="Delete Selected", command=delete_selected).pack(side="left", padx=5)
    Button(button_frame, text="Refresh", command=refresh_table).pack(side="left", padx=5)

    # build the new tabs; users only see Find Route
    build_route_tab(frame3)
    build_incident_tab(frame4)
    build_history_tab(frame5)
    if role != "admin":
        for tab in (frame1, frame2, frame4, frame5):
            notebook.forget(tab)

    refresh_table()
    refresh_places()
    refresh_incident_roads()
    refresh_history()

    root.mainloop()





# Submit button
def submit_form():
    source = to_atom(entries["Source"].get())
    destination = to_atom(entries["Destination"].get())
    distance = entries["Distance (In Kilometers)"].get()
    travel_time = entries["Travel Time (Mins)"].get()
    road_type = entries["Road Type"].get().lower().replace(" ", "_")
    special = entries["Special Condition"].get().lower().replace(" ", "_")
    status = entries["Road Status"].get().lower()
    direction = entries["Direction"].get().lower().replace("-", "_")
    bidirectional = "no" if direction == "one_way" else "yes"

    # reject bad input and duplicates, add the 5-minute penalty and close unusable roads
    if not source or not destination:
        showerror("Invalid data", "Source and destination must be place names: start with a letter and use only letters, digits and spaces.")
        return
    if source == destination:
        showerror("Invalid data", "Source and destination must be different places.")
        return
    try:
        distance_value = float(distance)
        time_value = float(travel_time)
    except ValueError:
        showerror("Invalid data", "Distance and Time must be numbers.")
        return
    if distance_value <= 0 or time_value < 0:
        showerror("Invalid data", "Distance must be greater than 0 and Time cannot be negative.")
        return
    if road_exists(source, destination, bidirectional):
        showerror("Duplicate road", "That road already exists. Use Update Network to change it.")
        return
    extra = ""
    penalty = penalty_change("none", special)
    if penalty:
        extra += f"\n{penalty} minutes were added because of the road condition."
    if special in FORCE_CLOSED:
        status = "closed"
        extra += "\nThe road was set to closed because of its condition."
    distance = str(fmt_time(distance_value))
    travel_time = str(fmt_time(time_value + penalty))

    # Create Prolog fact
    fact = (
        f"location(source({source}),"
        f"destination({destination}),"
        f"distance({distance}),"
        f"time({travel_time}),"
        f"type({road_type}),"
        f"special({special}),"
        f"status({status}),"
        f"bidirectional({bidirectional}))."
    )

    # Write to file
    with open(file_path, "a") as file:
        file.write(fact + "\n")
    
    print("Successfully Added New Location: ", fact)

    # send the new road to Prolog and refresh the other tabs
    load_into_prolog()
    refresh_table()
    refresh_places()
    refresh_incident_roads()

    showinfo("Success", "Road network data saved." + extra)




def login(username, password, window):
    if (username == "admin" and password == "password"):
        showinfo("Login Successful", "Welcome, Admin!")
        window.destroy()
        main_window()
    else:
        showerror("Login Failed", "Incorrect user ID or password.")
        
# opens the app with only the Find Route tab
def user_login(window):
    window.destroy()
    main_window("user")


login_window()
